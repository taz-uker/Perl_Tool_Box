#!/usr/local/ActivePerl-5.16/bin/perl
#
# This program does the reverse of the cat command
#
# program name: tac_tp.pl 
# 
# written by Terry Pensel 
#
use 5.014;


# Variable list

print reverse <> ;