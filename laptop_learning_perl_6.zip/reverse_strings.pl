#!/usr/bin/perl
#
print "Enter some words and Hit Control-D when you are done.\n";
